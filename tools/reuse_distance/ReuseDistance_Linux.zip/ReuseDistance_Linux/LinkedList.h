using namespace std;
#include <iostream>
#ifndef LINKEDLIST_H
#define LINKEDLIST_H

enum Request_Type {
	Read,
	Write,
	Discard,
	Sync,
	All,
	Invalid
};

struct Data {
	uint64_t Time;
	uint64_t Address;
	uint64_t Size;
	Request_Type Type;
};

struct Statistical_Value {
	uint64_t Count;
	uint64_t Size;
	uint64_t Time;
};

struct Node
{
	Data Value;
	Node *Next;
};

class LinkedList
{
public:
	LinkedList();
	~LinkedList();
	void InsertAtBack(struct Data ValueToInsert);
	bool RemoveAnItem(struct Data ValueToRemove,struct Statistical_Value* Value);

private:
	Node *First;
	Node *Last;
};

#endif