#include <iostream>
#include <fstream>
#include <vector>
#include <string>
#include <list>
#include <cfloat>
#include <algorithm>
#include "LinkedList.h"

using namespace std;


struct Stat_Value_vector {
	uint64_t Address;
	vector<uint64_t> Count;
	vector<uint64_t> Size;
	vector<uint64_t> Time;
};

struct Reuse_Address {
	uint64_t Address;
	uint32_t Count;
};

bool Vector_Search(vector<Reuse_Address> Reuse_Addresses, uint64_t Address);
bool Stat_Value_vector_Search(vector<Stat_Value_vector>* Stat_Value_vector_Ins,
	Statistical_Value Stat_Value, uint64_t Address);
vector<string> explode(const string& str, const char& ch);
void Calculate_stat(vector<Stat_Value_vector> Stat_Value_vector_Ins, char* Output_Address);
void Calculate_Medium(vector<uint64_t> Data, double *Medium, double *Medium_Frequency);
void Calculate_Mode(vector<uint64_t> Data, double *Mode, double *Mode_Frequency);


int main(int argc, char **argv)
{


	char* Address_Input = "preprocess_trace.txt";
	char* ReuseAddress_Input = "preprocess_access_freq.csv";
	char* Address_Output = "out.txt";
	int Address_position = 7;
	int Size_position = 9;
	int TimeStamp_position = 3;
	int RequestType_position = 6;
	char RequestType_NRW = 'N';
	char Line_Delimeter = ' ';
	char* Read_word1 = "R";
	char* Read_word2 = "RA";
	char* Read_word3 = "RS";
	char* Write_word1 = "W";
	char* Write_word2 = "WA";
	char* Write_word3 = "WS";
	int Coefficient_Address_byte = 512;
	int Coefficient_Size_byte = 512;
	int Coefficient_Time_ns = 1000000000;


	/* Read Reuse Addresses & Count */
	string one_line;
	vector<string> Field;
	Reuse_Address New_Reuse_Address;
	vector<Reuse_Address> Reuse_Addresses;
	ifstream Reuse_File;
	Reuse_File.open(ReuseAddress_Input, ios::in);

	while (!Reuse_File.eof()) {
		Reuse_File >> one_line;
		Field = explode(one_line, ',');
		New_Reuse_Address.Address = stoull(Field[0])*Coefficient_Address_byte;
		New_Reuse_Address.Count = stoull(Field[1]);
		Reuse_Addresses.push_back(New_Reuse_Address);
	}
	Reuse_File.close();

	/* Open Output File */
	ofstream Output_File;
	Output_File.open(Address_Output,ios::out);
	Output_File << "Address\tmax_count\tmax_count_frequency\tmin_count\tmin_count_frequency\t"
		"average_count_rd\t"
		"medium_count\tmedium_count_frequency\tmode_count\tmode_count_frequency\t"
		"max_size\tmax_size_frequency\tmin_size\tmin_size_frequency\t"
		"average_size_rd\t"
		"medium_size\tmedium_size_frequency\tmode_size\tmode_size_frequency\t"
		"max_time\tmax_time_frequency\tmin_time\tmin_time_frequency\t"
		"average_time_rd\t"
		"medium_time\tmedium_time_frequency\tmode_time\tmode_time_frequency\t\n";
	Output_File.close();

	/* Open Input File */
	LinkedList Reuse_List;
	Statistical_Value Stat_Value;
	vector<Stat_Value_vector> Stat_Value_vector_Ins;
	struct Data New_Request;
	vector<string> Fields;
	ifstream Input_File;
	Input_File.open(Address_Input, ios::in);
	while (!Input_File.eof()) {
		getline(Input_File,one_line);
		if (one_line == "")
			break;
		Fields = explode(one_line,Line_Delimeter);
		if (RequestType_NRW == 'N') {
			New_Request.Type = All;
		}
		else if (Fields[RequestType_position] == Read_word1 || Fields[RequestType_position] == Read_word2 || Fields[RequestType_position] == Read_word3) {
			New_Request.Type = Read;
		}
		else if (Fields[RequestType_position] == Write_word1 || Fields[RequestType_position] == Write_word2 || Fields[RequestType_position] == Write_word3) {
			New_Request.Type = Write;
		}
		cout << Fields[Address_position] << endl;
		New_Request.Address = stoull(Fields[Address_position])*Coefficient_Address_byte;
		New_Request.Size = stoull(Fields[Size_position]) * Coefficient_Size_byte;
		New_Request.Time = (uint64_t)stod(Fields[TimeStamp_position]) * Coefficient_Time_ns;
		if (New_Request.Type == All) {
			if (Vector_Search(Reuse_Addresses, New_Request.Address)) {
				Reuse_List.RemoveAnItem(New_Request, &Stat_Value);
				if (Stat_Value.Time != 0) {
					Stat_Value_vector_Search(&Stat_Value_vector_Ins, Stat_Value, New_Request.Address);
				}
			}
			Reuse_List.InsertAtBack(New_Request);
		}

		else if (New_Request.Type == Read && RequestType_NRW == 'R') {
			if (Vector_Search(Reuse_Addresses, New_Request.Address)) {
				Reuse_List.RemoveAnItem(New_Request, &Stat_Value);
				if (Stat_Value.Time != 0) {
					Stat_Value_vector_Search(&Stat_Value_vector_Ins, Stat_Value, New_Request.Address);
				}
			}
			Reuse_List.InsertAtBack(New_Request);
		}

		else if (New_Request.Type == Write && RequestType_NRW == 'W') {
			if (Vector_Search(Reuse_Addresses, New_Request.Address)) {
				Reuse_List.RemoveAnItem(New_Request, &Stat_Value);
				if (Stat_Value.Time != 0) {
					Stat_Value_vector_Search(&Stat_Value_vector_Ins, Stat_Value, New_Request.Address);
				}
			}
			Reuse_List.InsertAtBack(New_Request);
		}
	}

	Calculate_stat(Stat_Value_vector_Ins,Address_Output);

	return 0;
}


bool Vector_Search(vector<Reuse_Address> Reuse_Addresses, uint64_t Address) {
	for (size_t i = 0; i < Reuse_Addresses.size(); i++) {
		if (Reuse_Addresses[i].Address == Address && Reuse_Addresses[i].Count > 0) {
			Reuse_Addresses[i].Count--;

			if (Reuse_Addresses[i].Count == 0)
				Reuse_Addresses.erase(Reuse_Addresses.begin()+i-1);

			return true;
		}
	}

	return false;
}

bool Stat_Value_vector_Search(vector<Stat_Value_vector>* Stat_Value_vector_Ins, 
	Statistical_Value Stat_Value, uint64_t Address) {
	for (size_t i = 0; i < (*Stat_Value_vector_Ins).size(); i++) {
		if ((*Stat_Value_vector_Ins)[i].Address == Address) {
			(*Stat_Value_vector_Ins)[i].Count.push_back(Stat_Value.Count);
			(*Stat_Value_vector_Ins)[i].Size.push_back(Stat_Value.Size);
			(*Stat_Value_vector_Ins)[i].Time.push_back(Stat_Value.Time);
			return true;
		}
	}

	Stat_Value_vector temp;
	temp.Address = Address;
	temp.Count.push_back(Stat_Value.Count);
	temp.Size.push_back(Stat_Value.Size);
	temp.Time.push_back(Stat_Value.Time);
	(*Stat_Value_vector_Ins).push_back(temp);
	return true;
}


vector<string> explode(const string& str, const char& ch) {
	string next;
	vector<string> result;

	// For each character in the string
	for (string::const_iterator it = str.begin(); it != str.end(); it++) {
		// If we've hit the terminal character
		if (*it == ch) {
			// If we have some characters accumulated
			if (!next.empty()) {
				// Add them to the result vector
				result.push_back(next);
				next.clear();
			}
		}
		else {
			// Accumulate the next character into the sequence
			next += *it;
		}
	}
	if (!next.empty())
		result.push_back(next);
	return result;
}

void Calculate_stat(vector<Stat_Value_vector> Stat_Value_vector_Ins, char* Output_Address){
	ofstream Output_File;
	Output_File.open(Output_Address, ios::app);

	double Count_Max = -1;
	double Time_Max = -1;
	double Size_Max = -1;
	double Count_Max_Frequency = 0;
	double Time_Max_Frequency = 0;
	double Size_Max_Frequency = 0;
	double Count_Min = DBL_MAX;
	double Time_Min = DBL_MAX;
	double Size_Min = DBL_MAX;
	double Count_Min_Frequency = 0;
	double Time_Min_Frequency = 0;
	double Size_Min_Frequency = 0;
	double Count_Avg = 0;
	double Time_Avg = 0;
	double Size_Avg = 0;
	double Count_Mode = 0;
	double Time_Mode = 0;
	double Size_Mode = 0;
	double Count_Mode_Frequency = 0;
	double Time_Mode_Frequency = 0;
	double Size_Mode_Frequency = 0;
	double Count_Medium = 0;
	double Time_Medium = 0;
	double Size_Medium = 0;
	double Count_Medium_Frequency = 0;
	double Time_Medium_Frequency = 0;
	double Size_Medium_Frequency = 0;

	for (size_t i = 0; i < Stat_Value_vector_Ins.size(); i++) {

		Count_Max = -1;
		Time_Max = -1;
		Size_Max = -1;
		Count_Max_Frequency = 0;
		Time_Max_Frequency = 0;
		Size_Max_Frequency = 0;
		Count_Min = DBL_MAX;
		Time_Min = DBL_MAX;
		Size_Min = DBL_MAX;
		Count_Min_Frequency = 0;
		Time_Min_Frequency = 0;
		Size_Min_Frequency = 0;
		Count_Avg = 0;
		Time_Avg = 0;
		Size_Avg = 0;
		Count_Mode = 0;
		Time_Mode = 0;
		Size_Mode = 0;
		Count_Mode_Frequency = 0;
		Time_Mode_Frequency = 0;
		Size_Mode_Frequency = 0;
		Count_Medium = 0;
		Time_Medium = 0;
		Size_Medium = 0;
		Count_Medium_Frequency = 0;
		Time_Medium_Frequency = 0;
		Size_Medium_Frequency = 0;

		Output_File << Stat_Value_vector_Ins[i].Address << "\t";

		//Count
		for (size_t j = 0; j < Stat_Value_vector_Ins[i].Count.size();j++) {
			if (Count_Min > Stat_Value_vector_Ins[i].Count[j]) {
				Count_Min = Stat_Value_vector_Ins[i].Count[j];
				Count_Min_Frequency = 1;
			}
			else if (Count_Min == Stat_Value_vector_Ins[i].Count[j]) {
				Count_Min_Frequency++;
			}

			if (Count_Max < Stat_Value_vector_Ins[i].Count[j]) {
				Count_Max = Stat_Value_vector_Ins[i].Count[j];
				Count_Max_Frequency = 1;
			}
			else if (Count_Max == Stat_Value_vector_Ins[i].Count[j]) {
				Count_Max_Frequency++;
			}

			Count_Avg += Stat_Value_vector_Ins[i].Count[j];
		}
		Count_Avg = (double)Count_Avg / Stat_Value_vector_Ins[i].Count.size();
		Calculate_Medium(Stat_Value_vector_Ins[i].Count, &Count_Medium, &Count_Medium_Frequency);
		Calculate_Mode(Stat_Value_vector_Ins[i].Count, &Count_Mode, &Count_Mode_Frequency);

		Output_File << fixed << Count_Max << "\t";
		Output_File << fixed << Count_Max_Frequency << "\t";
		Output_File << fixed << Count_Min << "\t";
		Output_File << fixed << Count_Min_Frequency << "\t";
		Output_File << fixed << Count_Avg << "\t";
		Output_File << fixed << Count_Medium << "\t";
		Output_File << fixed << Count_Medium_Frequency << "\t";
		Output_File << fixed << Count_Mode << "\t";
		Output_File << fixed << Count_Mode_Frequency << "\t";

		//Size
		for (size_t j = 0; j < Stat_Value_vector_Ins[i].Size.size(); j++) {
			if (Size_Min > Stat_Value_vector_Ins[i].Size[j]) {
				Size_Min = Stat_Value_vector_Ins[i].Size[j];
				Size_Min_Frequency = 1;
			}
			else if (Size_Min == Stat_Value_vector_Ins[i].Size[j]) {
				Size_Min_Frequency++;
			}

			if (Size_Max < Stat_Value_vector_Ins[i].Size[j]) {
				Size_Max = Stat_Value_vector_Ins[i].Size[j];
				Size_Max_Frequency = 1;
			}
			else if (Size_Max == Stat_Value_vector_Ins[i].Size[j]) {
				Size_Max_Frequency++;
			}

			Size_Avg += Stat_Value_vector_Ins[i].Size[j];
		}
		Size_Avg = (double)Size_Avg / Stat_Value_vector_Ins[i].Size.size();
		Calculate_Medium(Stat_Value_vector_Ins[i].Size, &Size_Medium, &Size_Medium_Frequency);
		Calculate_Mode(Stat_Value_vector_Ins[i].Size, &Size_Mode, &Size_Mode_Frequency);

		Output_File << fixed << Size_Max << "\t";
		Output_File << fixed << Size_Max_Frequency << "\t";
		Output_File << fixed << Size_Min << "\t";
		Output_File << fixed << Size_Min_Frequency << "\t";
		Output_File << fixed << Size_Avg << "\t";
		Output_File << fixed << Size_Medium << "\t";
		Output_File << fixed << Size_Medium_Frequency << "\t";
		Output_File << fixed << Size_Mode << "\t";
		Output_File << fixed << Size_Mode_Frequency << "\t";

		//Time
		for (size_t j = 0; j < Stat_Value_vector_Ins[i].Time.size(); j++) {
			if (Time_Min > Stat_Value_vector_Ins[i].Time[j]) {
				Time_Min = Stat_Value_vector_Ins[i].Time[j];
				Time_Min_Frequency = 1;
			}
			else if (Time_Min == Stat_Value_vector_Ins[i].Time[j]) {
				Time_Min_Frequency++;
			}

			if (Time_Max < Stat_Value_vector_Ins[i].Time[j]) {
				Time_Max = Stat_Value_vector_Ins[i].Time[j];
				Time_Max_Frequency = 1;
			}
			else if (Time_Max == Stat_Value_vector_Ins[i].Time[j]) {
				Time_Max_Frequency++;
			}

			Time_Avg += Stat_Value_vector_Ins[i].Time[j];
		}
		Time_Avg = (double)Time_Avg / Stat_Value_vector_Ins[i].Time.size();
		Calculate_Medium(Stat_Value_vector_Ins[i].Time, &Time_Medium, &Time_Medium_Frequency);
		Calculate_Mode(Stat_Value_vector_Ins[i].Time, &Time_Mode, &Time_Mode_Frequency);

		Output_File << fixed << Time_Max << "\t";
		Output_File << fixed << Time_Max_Frequency << "\t";
		Output_File << fixed << Time_Min << "\t";
		Output_File << fixed << Time_Min_Frequency << "\t";
		Output_File << fixed << Time_Avg << "\t";
		Output_File << fixed << Time_Medium << "\t";
		Output_File << fixed << Time_Medium_Frequency << "\t";
		Output_File << fixed << Time_Mode << "\t";
		Output_File << fixed << Time_Mode_Frequency << "\t";

		Output_File << endl;
	}

	Output_File.close();
}

void Calculate_Medium(vector<uint64_t> Data, double *Medium, double *Medium_Frequency) {

	*Medium = 0;
	*Medium_Frequency = 0;
	sort(Data.begin(), Data.end());
	if (Data.size() % 2 == 0) {
		*Medium = ((Data[(int)(Data.size() / 2)] + Data[(int)(Data.size() / 2 - 1)]) / (double)2);
		for (size_t i = 0; i < Data.size(); i++) {
			if (Data[(int)(Data.size() / 2)] == Data[i]) {
				*Medium_Frequency += 1;
			}
			else if (Data[(int)(Data.size() / 2) - 1] == Data[i]) {
				*Medium_Frequency += 1;
			}
		}
		if (Data[(int)(Data.size() / 2)] != Data[(int)(Data.size() / 2) - 1])
			*Medium_Frequency /= 2;
	}
	else {
		*Medium = (Data[(int)(Data.size())/2]);
		for (size_t i = 0; i < Data.size(); i++) {
			if (Data[(int)(Data.size() / 2)] == Data[i]) {
				*Medium_Frequency+=1;
			}
		}

	}
}


void Calculate_Mode(vector<uint64_t> Data, double *Mode, double *Mode_Frequency) {
	struct Mode_struct{
		uint64_t value;
		int count;
	};
	struct Mode_struct temp;
	vector<Mode_struct> Data_temp;

	sort(Data.begin(), Data.end());
	temp.count = 0;
	temp.value = Data[0];
	Data_temp.push_back(temp);
	for (size_t i = 0, j = 0; i < Data.size(); i++) {
		if (Data[i] == Data_temp[j].value) {
			Data_temp[j].count++;
		}
		else {
			temp.count = 1;
			temp.value = Data[i];
			Data_temp.push_back(temp);
			j++;
		}
	}

	int Max = 0;
	int Count = 0;
	double Sum = 0;
	for (size_t i = 0; i < Data_temp.size(); i++) {
		if (Data_temp[i].count > Max) {
			Max = Data_temp[i].count;
			Sum = Data_temp[i].value;
			Count = 1;
		}
		else if (Data_temp[i].count == Max){
			Sum += Data_temp[i].value;
			Count++;
		}
	}

	*Mode = Sum / Count;
	*Mode_Frequency = Max;

}
