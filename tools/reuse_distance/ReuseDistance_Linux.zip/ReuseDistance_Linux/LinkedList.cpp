#include "LinkedList.h"


LinkedList::LinkedList()
{
	First = NULL;
	Last = NULL;
}


LinkedList::~LinkedList()
{
	Node* Temp = First;
	while (Temp != NULL)
	{
		Temp = Temp->Next;
		delete(First);
		First = Temp;
	}

	First = NULL;
	Last = NULL;
}


void LinkedList::InsertAtBack(struct Data ValueToInsert)
{
	Node* NewNode = new Node;
	NewNode->Value = ValueToInsert;
	NewNode->Next = NULL;

	if (First == NULL && Last == NULL) {
		First = Last = NewNode;
	}

	else if (First == Last) {
		First->Next = NewNode;
		Last = NewNode;
	}

	else {
		Last->Next = NewNode;
		Last = Last->Next;
	}
}


bool LinkedList::RemoveAnItem(struct Data DataToRemove, struct Statistical_Value* Value) {
	
	Value->Count = 0;
	Value->Size = 0;
	Value->Time = 0;

	if (First == NULL && Last == NULL) { 
		return false;
	}

	if (First == Last) {
		if (First->Value.Address == DataToRemove.Address && First->Value.Type != DataToRemove.Type) {
			Value->Count = 0;
			Value->Size = 0;
			Value->Time = DataToRemove.Time - First->Value.Time;

			delete(First);
			First = Last = NULL;

			return true;
		}
		return false;
	}

	else
	{
		Node* Temp = First;
		Node* Prev_Temp = NULL;

		while (Temp != NULL)
		{
			if (Temp->Value.Address == DataToRemove.Address && Temp->Value.Type == DataToRemove.Type) {
				break;
			}
			else {
				Prev_Temp = Temp;
				Temp = Temp->Next;
			}
		}

		if (Temp == NULL) {
			return false;
		}

		if (Prev_Temp == NULL) {
			Prev_Temp = Temp->Next;
			First = Prev_Temp;
			Value->Count++;
			Value->Size += Prev_Temp->Value.Size;
		}
		else {
			Prev_Temp->Next = Temp->Next;
		}

		Value->Time = DataToRemove.Time - Temp->Value.Time;
		delete(Temp);

		if (Prev_Temp->Next == NULL)
			Last = Prev_Temp;

		else {
			Temp = Prev_Temp->Next;
			while (Temp != NULL) {
				Value->Count++;
				Value->Size += Temp->Value.Size;
				Temp = Temp->Next;
			}
		}

		return true;
	}
}